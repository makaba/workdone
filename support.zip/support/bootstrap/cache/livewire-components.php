<?php return array (
  'blocked-user-search' => 'App\\Http\\Livewire\\BlockedUserSearch',
  'categories' => 'App\\Http\\Livewire\\Categories',
  'customer-ticket' => 'App\\Http\\Livewire\\CustomerTicket',
  'customers' => 'App\\Http\\Livewire\\Customers',
  'faqfront' => 'App\\Http\\Livewire\\Faqfront',
  'list-categories' => 'App\\Http\\Livewire\\ListCategories',
  'list-public-ticket' => 'App\\Http\\Livewire\\ListPublicTicket',
  'search-users' => 'App\\Http\\Livewire\\SearchUsers',
  'ticket-replay' => 'App\\Http\\Livewire\\TicketReplay',
  'tickets' => 'App\\Http\\Livewire\\Tickets',
  'users' => 'App\\Http\\Livewire\\Users',
);