ALTER TABLE `users` ADD `email_update` TINYINT(1) NOT NULL DEFAULT '1' AFTER `region_code_flag`;
