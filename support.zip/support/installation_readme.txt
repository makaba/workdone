upload to xammp server 7.4
upload the database "support" on the root directory

run "php artisan install"

run "php artisan serve"(composer is needed)

log in

email: admin@support.com

password: 123456
